uses("core.http.TrestClient");
uses("core.collections.TarrayCollection");

defineClass("TcrudGenericCalls", "core.events.TeventDispatcher", { 

	apiUrl: null,
	liste: null,
	listeSearchOptions: null,
	lastIdSearch: null,
	className: null,
	cached: false,
	listeIsSet: false,


	constructor: function(args){
		this._super.constructor.call(this,args);	
		this.injectParam("apiUrl", args.apiUrl, true);

		this.liste = new TarrayCollection();
		this.restClient = new TrestClient({baseUrl: this.apiUrl, dataType:"json"});
	},
	defaultErrorHandler: function(e, token)
	{  
		logger.error(e.data.url+" => "+e.data.responseText);
		
	},

	
	_onupdateDefault: function(evt, token)
	{
		//evt.data => objtet Vip
		if (defined(token.extSuccess))
			token.extSuccess(evt.data, token);
		
	},
	_onsearchDefault: function(evt, token)
	{
		if (defined(token.extSuccess))
			token.extSuccess(evt.data, token);
		
	},
	_onremoveDefault: function(evt, token)
	{
		if (defined(token.extSuccess))
			token.extSuccess(evt.data, token);
		this.onRemove(this, evt.data);
	},

	_ongetByIdDefault: function(evt, token)
	{
		if (token.updateModel)
		{
			var item = evt.data;
			if (evt.data != null)
			{
				var itemModel = this.liste.getByProp("id", evt.data.id);

				if (itemModel != null)
				{
					//L'item existe
					this.liste.replaceItem(itemModel, item);				
				}	
			}
		}
 		if (defined(token.extSuccess))
			token.extSuccess(evt.data, token);	
	},

	onUpdate: function(className, data)
	{

	},
	onRemove: function(className, data)
	{

	},
	//*********************************************************************************************************
	//********************************************  CRUD  *****************************************************
	//*********************************************************************************************************

	getById: function(id, success, failure, updateModel)
	{
		if (arguments.length < 4)
			updateModel = true;

		var token = {extSuccess:success, extFailure:failure, updateModel: updateModel, searchId: id};
		var data = null;

		if ((this.cached == false) || (this.listeIsSet == false)|| (this.lastIdSearch!= id))
		{
			this.restClient.get(this.url+"/"+id, "" , data, this._ongetById.bind(this), failure||this.defaultErrorHandler, token);	
		}
		else
		{
			this.lastIdSearch = id;
			var itemModel = this.liste.getByProp("id", id);
			token.extSuccess(itemModel);	
		}
	},

	_ongetById: function(evt, token)
	{
		this.lastIdSearch = token.searchId;
		this._ongetByIdDefault(evt, token);	
	},

	update: function(obj, success, failure)
	{
		var token = { extSuccess:success, extFailure:failure};
		var data = {data: JSON.stringify(obj)};

		this.restClient.post(this.url, "" , data, this._onupdate.bind(this), failure||this.defaultErrorHandler, token);
	},

	_onupdate: function(evt, token)
	{
		this.updateModel(evt.data)
       	//Pour recharger les grilles attachées au modèle
        //this.search(this.listeSearchOptions); 
        this._onupdateDefault(evt, token);
	},

	updateModel: function(item)
	{
		if (item == null)
		{
			logger.warn("TgenericCall.updateModel => item=null");
			return;
		}
		else
		{
			var itemModel = this.liste.getByProp("id", item.id);

			if (itemModel != null)
			{
				//TESTER LA DATE DE MODIF de l'objet dans le model: elle est peut-être plus récente.

				if (item.date_modif <= itemModel.date_modif)
				{
					if (item.date_modif < itemModel.date_modif)
					{
						logger.warn("ATTENTION: l'objet reçu "+this.className+" est obsolète ! Il ne sera pas mis à jour dans le model");
						logger.warn("item.date_modif = "+item.date_modif+" itemModel.date_modif="+itemModel.date_modif);
					}
					if (item.date_modif == itemModel.date_modif)
						logger.warn("Date inchangée: item.date_modif = "+item.date_modif+" itemModel.date_modif="+itemModel.date_modif);
				}
				else
				{
						//L'item existe
					logger.info("Item Modifiée");
					this.liste.replaceItem(itemModel, item);			
				}
			}
	       	else
	       	{
	       		//création ou pas dans le model
	       		if (item._isNew == true){
					logger.info("Création item");
	       			this.liste.addItemAt(item,0);
	       		}
	       	}	
		}
		 	
       	this.onUpdate(this, itemModel, item);
	
       	return itemModel;
	},

	remove: function(id, success, failure)
	{
		var token = {extSuccess:success, extFailure:failure};
		var data = null;

		this.restClient.del(this.url+"/"+id, "" , data, this._onremove.bind(this), failure||this.defaultErrorHandler, token);
	},

	_onremove: function(evt, token)
	{
		this.removeModel(evt.data)
		this._onremoveDefault(evt, token);
	},	
	removeModel: function(itemId)
	{
		var itemModel = this.liste.getByProp("id", itemId);
		this.liste.removeItem(itemModel);
	},
	search: function(searchOptions, success, failure, _updateModel)
	{
		this.startSearch = new Date();
		if (arguments.length < 4)
			_updateModel = true;
	
		if (searchOptions == null)
			searchOptions = "";
		
		if (searchOptions.startsWith("&"))
			searchOptions = searchOptions.substring(1);
	
	
		var token = {url: this.url, extSuccess:success, extFailure:failure, searchOptions: searchOptions, updateModel:_updateModel};
		var data = null;
		
		if ((this.cached == false) || (this.listeIsSet == false) || (this.listeSearchOptions != searchOptions))
		{
			this.restClient.get(this.url, searchOptions , data, this._onsearch.bind(this), failure||this.defaultErrorHandler, token);		
		}
		else
		{
			var data = {total: this.liste.length, data: this.liste, processTime:0};
			this.liste.refresh();
			token.extSuccess(data);
		}
		
	},

	_onsearch: function(evt, token)
	{
		var debut = new Date();
		var tempsAppel = (debut - this.startSearch);
		var tempsCpuServeur =  Math.round(evt.data.processTime*1000);
	
		logger.debug("Temps traitement ("+tempsAppel +"ms) = Temps serveur ("+tempsCpuServeur+"ms) + encodage/decodage Json ("+ (tempsAppel - tempsCpuServeur)+" ms) token.updateModel="+token.updateModel) ;
		
		if (token.updateModel)
		{
			this.liste.setSource(evt.data.data);
			this.liste.total = evt.data.total;
			evt.data.data = this.liste;
			this._onsearchDefault(evt, token);	
			this.listeIsSet = true;
			this.listeSearchOptions = token.searchOptions;
		}
		else
		{
			var l = new TarrayCollection();
			l.setSource(evt.data.data);
			l.total = evt.data.total;
			evt.data.data = l;	
			this._onsearchDefault(evt, token);	
		}
		
		var fin = new Date();
 		logger.debug("Temps maj model = "+ (fin - debut)+" ms") ;
 			
	}
});
