uses("core.http.TrestClient");
uses("core.http.TcrudGenericCalls");

defineClass("TcrudService", "core.events.TeventDispatcher", { 

	objectClasses: [],
	apiUrl:null,
	localStorageId: null,

	constructor: function(args){
		this._super.constructor.call(this,args);				

		/* Le serveur ne renvoie que des 200, avec champs "exitCode" et "errorText".
			avec jsonp (l'api est sur un autre domaine), ça permet de récupérer les erreurs.
		*/

		this.injectParam("apiUrl", args.apiUrl, true);

		if (this.localStorageId == null)
		this.localStorageId = "localStorage_"+panjs.env;
		
		this.restClient = new TrestClient({baseUrl: this.apiUrl, dataType:"json"});
	
		for (var i =0; i< this.objectClasses.length; i++)		
		{
			var classe = this.objectClasses[i];

			var caller = new TcrudGenericCalls({apiUrl: this.apiUrl});
			caller.url = classe.url;
			caller.className = classe.nom;
			caller.cached =  classe.cached || false;
			
			this["caller"+classe.nom] = caller;
			this["get"+classe.nom+"ById"] = caller.getById.bind(caller);
			this["update"+classe.nom] = caller.update.bind(caller);
			this["delete"+classe.nom] = caller.remove.bind(caller);
			this["search"+classe.nom] = caller.search.bind(caller);

			caller.onUpdate = this.onCallerUpdate.bind(this);
			caller.onRemove = this.onCallerRemove.bind(this);

		}
	},
	onCallerUpdate: function(sender, oldData, newData){
		var evt =  new Tevent(sender.className+"Update", {newData:newData, oldData: oldData});
		this.dispatchEvent(evt);
	},

	onCallerRemove: function(sender, id){
		this.dispatchEvent( new Tevent(sender.className+"Delete", id));
	},

	defaultErrorHandler: function(e)
	{  
		logger.error(e.data.url+" => "+e.data.statusText);
		logger.error(e.data.url+" => "+e.data.responseText);
	},
	
	_onRequestSuccesDefault: function(evt, token)
	{
		//evt.data => objtet Vip
		if (defined(token.extSuccess))
			token.extSuccess(evt.data);
	},

	/* LocalStorage */
	getValue: function (name, success, failure) {

		var key = this.localStorageId+"."+name;
		var item = localStorage.getItem(key);
		var result = null;

		if (item != null){
			try{
				result = JSON.parse(item);
			}catch(e)
			{
				logger.error("Erreur TcrudService.getValue: "+e);
				if (defined(failure))
					failure(e);
				return result;
			}
		}

		if (defined(success))
			success(result);

		return result;
	},

	setValue: function (name, value, success, failure) {
		var key = this.localStorageId+"."+name;
		try{
			localStorage.setItem(key, JSON.stringify(value));
		}catch(e)
		{
			logger.error("Erreur TcrudService.setValue: "+e);
			if (defined(failure))
			failure(e);

			return false;
		}
		if (defined(success))
			success(value);
		return true;
	}
});
